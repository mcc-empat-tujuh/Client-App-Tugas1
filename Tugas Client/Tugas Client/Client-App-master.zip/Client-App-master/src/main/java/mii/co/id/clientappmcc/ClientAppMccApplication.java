package mii.co.id.clientappmcc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClientAppMccApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClientAppMccApplication.class, args);
	}

}
