package mii.co.id.clientappmcc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClientAppMccApplicationTests {

	@Test
	void contextLoads() {
	}

}
